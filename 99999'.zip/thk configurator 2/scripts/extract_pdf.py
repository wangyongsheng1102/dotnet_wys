"""
PDF文档提取脚本
用于从PDF文件中提取文本内容，帮助整理需求
"""
import os
import json
from pathlib import Path

try:
    import pdfplumber
    PDFPLUMBER_AVAILABLE = True
except ImportError:
    PDFPLUMBER_AVAILABLE = False
    print("警告: pdfplumber未安装，请运行: pip install pdfplumber")


def extract_text_from_pdf(pdf_path: str) -> str:
    """从PDF文件中提取文本"""
    if not PDFPLUMBER_AVAILABLE:
        return "需要安装pdfplumber: pip install pdfplumber"
    
    text = ""
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n\n"
    except Exception as e:
        return f"提取PDF时出错: {str(e)}"
    
    return text


def extract_all_pdfs(base_dir: str):
    """提取目录下所有PDF文件的内容"""
    base_path = Path(base_dir)
    pdf_files = list(base_path.glob("*.pdf"))
    
    results = {}
    
    for pdf_file in pdf_files:
        print(f"正在处理: {pdf_file.name}")
        text = extract_text_from_pdf(str(pdf_file))
        results[pdf_file.name] = text
        
        # 保存到文本文件
        output_file = base_path / f"{pdf_file.stem}.txt"
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"已保存到: {output_file}")
    
    # 保存汇总JSON
    summary_file = base_path / "pdf_extracts_summary.json"
    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"汇总已保存到: {summary_file}")
    
    return results


if __name__ == "__main__":
    # 获取项目根目录
    script_dir = Path(__file__).parent
    project_root = script_dir.parent
    
    print("开始提取PDF文档...")
    extract_all_pdfs(str(project_root))
    print("完成！")

"""
国际化API路由
"""
from fastapi import APIRouter
from typing import Dict

router = APIRouter()


@router.get("/translations/{language}")
async def get_translations(language: str) -> Dict[str, str]:
    """
    获取指定语言的翻译文本
    language: ja (日语) 或 en (英语)
    """
    # TODO: 从PDF文档中提取的日英对照表，建立翻译文件
    translations = {
        "ja": {
            "app.title": "THK VTS コンフィギュレーター",
            "app.welcome": "ようこそ",
            "configurator.title": "製品設定",
            "configurator.create": "新規作成",
            "configurator.save": "保存",
            "configurator.cancel": "キャンセル",
        },
        "en": {
            "app.title": "THK VTS Configurator",
            "app.welcome": "Welcome",
            "configurator.title": "Product Configuration",
            "configurator.create": "Create New",
            "configurator.save": "Save",
            "configurator.cancel": "Cancel",
        }
    }
    
    return translations.get(language, translations["en"])

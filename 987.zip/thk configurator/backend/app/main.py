"""
THK VTS Configurator Backend
FastAPI application entry point
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api import configurator, i18n
from app.core.config import settings

app = FastAPI(
    title="THK VTS Configurator API",
    description="THK VTS产品配置器后端API",
    version="2.0.0",
)

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
app.include_router(configurator.router, prefix="/api/v1/configurator", tags=["配置器"])
app.include_router(i18n.router, prefix="/api/v1/i18n", tags=["国际化"])


@app.get("/")
async def root():
    """根路径"""
    return {"message": "THK VTS Configurator API", "version": "2.0.0"}


@app.get("/health")
async def health_check():
    """健康检查"""
    return {"status": "healthy"}


@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """全局异常处理"""
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "message": str(exc)},
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

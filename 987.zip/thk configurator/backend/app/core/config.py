"""
应用配置
"""
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """应用设置"""
    APP_NAME: str = "THK VTS Configurator"
    APP_VERSION: str = "2.0.0"
    
    # CORS设置
    CORS_ORIGINS: list[str] = [
        "http://localhost:3000",
        "http://localhost:5173",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
    ]
    
    # API设置
    API_V1_PREFIX: str = "/api/v1"
    
    # 数据库设置（如需要）
    # DATABASE_URL: str = "sqlite:///./configurator.db"
    
    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()

# THK VTS Configurator Backend

FastAPI后端应用

## 安装

```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 运行

```bash
uvicorn app.main:app --reload
```

API文档将在以下地址可用：
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## API端点

### 配置器API
- `POST /api/v1/configurator/create` - 创建新配置
- `GET /api/v1/configurator/{id}` - 获取配置详情
- `GET /api/v1/configurator/` - 获取配置列表
- `PUT /api/v1/configurator/{id}` - 更新配置
- `DELETE /api/v1/configurator/{id}` - 删除配置

### 国际化API
- `GET /api/v1/i18n/translations/{language}` - 获取翻译文本

## 环境变量

创建 `.env` 文件：

```env
CORS_ORIGINS=http://localhost:3000,http://localhost:5173
```

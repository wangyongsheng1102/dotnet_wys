import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000'

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

export const configuratorService = {
  createConfiguration: async (data: {
    product_type: string
    parameters: Record<string, any>
    language: string
  }) => {
    const response = await apiClient.post('/api/v1/configurator/create', data)
    return response.data
  },
  getConfiguration: async (id: string) => {
    const response = await apiClient.get(`/api/v1/configurator/${id}`)
    return response.data
  },
  listConfigurations: async () => {
    const response = await apiClient.get('/api/v1/configurator/')
    return response.data
  },
  updateConfiguration: async (id: string, data: any) => {
    const response = await apiClient.put(`/api/v1/configurator/${id}`, data)
    return response.data
  },
  deleteConfiguration: async (id: string) => {
    const response = await apiClient.delete(`/api/v1/configurator/${id}`)
    return response.data
  },
}

export const i18nService = {
  getTranslations: async (language: string) => {
    const response = await apiClient.get(`/api/v1/i18n/translations/${language}`)
    return response.data
  },
}

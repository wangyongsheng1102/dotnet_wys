import { Routes, Route } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import Layout from './components/Layout'
import HomePage from './pages/HomePage'
import ConfiguratorPage from './pages/ConfiguratorPage'
import LanguageSwitcher from './components/LanguageSwitcher'

function App() {
  const { i18n } = useTranslation()

  return (
    <Layout>
      <LanguageSwitcher />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/configurator" element={<ConfiguratorPage />} />
      </Routes>
    </Layout>
  )
}

export default App

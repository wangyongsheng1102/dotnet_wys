import React from 'react'
import { useTranslation } from 'react-i18next'
import { Link } from 'react-router-dom'

const HomePage: React.FC = () => {
  const { t } = useTranslation()

  return (
    <div className="text-center">
      <h2 className="text-3xl font-bold text-gray-900 mb-4">
        {t('app.welcome')}
      </h2>
      <p className="text-lg text-gray-600 mb-8">
        {t('app.description')}
      </p>
      <Link
        to="/configurator"
        className="inline-block bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors"
      >
        {t('configurator.create')}
      </Link>
    </div>
  )
}

export default HomePage

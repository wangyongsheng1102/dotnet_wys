import React, { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { configuratorService } from '../services/api'

const ConfiguratorPage: React.FC = () => {
  const { t } = useTranslation()
  const [productType, setProductType] = useState('')
  const [parameters, setParameters] = useState<Record<string, any>>({})
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const response = await configuratorService.createConfiguration({
        product_type: productType,
        parameters,
        language: 'ja',
      })
      setResult(response)
    } catch (error) {
      console.error('Error creating configuration:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        {t('configurator.title')}
      </h2>
      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-sm p-6">
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('configurator.productType')}
          </label>
          <input
            type="text"
            value={productType}
            onChange={(e) => setProductType(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            required
          />
        </div>
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('configurator.parameters')}
          </label>
          <textarea
            value={JSON.stringify(parameters, null, 2)}
            onChange={(e) => {
              try {
                setParameters(JSON.parse(e.target.value))
              } catch {
                // Invalid JSON, ignore
              }
            }}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            rows={6}
            placeholder='{"key": "value"}'
          />
        </div>
        <div className="flex gap-4">
          <button
            type="submit"
            disabled={loading}
            className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 disabled:opacity-50"
          >
            {loading ? t('common.loading') : t('configurator.save')}
          </button>
          <button
            type="button"
            className="bg-gray-200 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-300"
          >
            {t('configurator.cancel')}
          </button>
        </div>
      </form>
      {result && (
        <div className="mt-6 bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">
            {t('configurator.result')}
          </h3>
          <pre className="bg-gray-50 p-4 rounded-lg overflow-auto">
            {JSON.stringify(result, null, 2)}
          </pre>
        </div>
      )}
    </div>
  )
}

export default ConfiguratorPage

export interface Configuration {
  configuration_id: string
  product_type: string
  parameters: Record<string, any>
  result: Record<string, any>
  status: string
}

export interface ConfigurationRequest {
  product_type: string
  parameters: Record<string, any>
  language: string
}

# 工具脚本

## extract_pdf.py

用于从PDF文档中提取文本内容的脚本。

### 使用方法

1. 安装依赖：
```bash
pip install pdfplumber
```

2. 运行脚本：
```bash
python scripts/extract_pdf.py
```

脚本会：
- 提取所有PDF文件的文本内容
- 将每个PDF的内容保存为对应的.txt文件
- 生成汇总的JSON文件

### 输出文件

- `{pdf文件名}.txt` - 每个PDF的文本内容
- `pdf_extracts_summary.json` - 所有PDF内容的汇总JSON

import React from 'react'

interface DesignReferenceProps {
  designFile: string
  alt?: string
  className?: string
}

/**
 * 设计稿参考组件
 * 用于在开发时显示设计稿参考
 */
const DesignReference: React.FC<DesignReferenceProps> = ({
  designFile,
  alt = '设计稿参考',
  className = '',
}) => {
  // 在生产环境中不显示设计稿
  if (import.meta.env.PROD) {
    return null
  }

  // 尝试从多个可能的路径加载设计稿
  const designPaths = [
    `/页面design/${designFile}`,
    `../页面design/${designFile}`,
    `../../页面design/${designFile}`,
    `../../../页面design/${designFile}`,
  ]

  return (
    <div className={`border-2 border-dashed border-gray-300 p-4 mb-4 bg-yellow-50 ${className}`}>
      <p className="text-xs text-gray-500 mb-2">
        📐 设计稿参考: {designFile} 
        <span className="ml-2 text-gray-400">(开发模式显示)</span>
      </p>
      <div className="relative">
        {designPaths.map((path, index) => (
          <img
            key={index}
            src={path}
            alt={alt}
            className={`max-w-full h-auto border border-gray-200 ${index > 0 ? 'hidden' : ''}`}
            style={{ maxHeight: '600px' }}
            onError={(e) => {
              // 如果当前路径失败，尝试下一个
              if (index < designPaths.length - 1) {
                const nextImg = e.currentTarget.parentElement?.querySelector(`img:nth-of-type(${index + 2})`) as HTMLImageElement
                if (nextImg) {
                  e.currentTarget.style.display = 'none'
                  nextImg.style.display = 'block'
                }
              }
            }}
          />
        ))}
        <p className="text-xs text-gray-400 mt-2">
          提示: 设计稿文件应位于项目根目录的 <code className="bg-gray-100 px-1 rounded">页面design/</code> 文件夹
        </p>
      </div>
    </div>
  )
}

export default DesignReference

/**
 * 设计稿分析工具
 * 用于记录和分析页面design文件夹中的设计稿
 */

export interface DesignPage {
  id: number
  filename: string
  description?: string
  pageType?: 'home' | 'configurator' | 'result' | 'settings' | 'other'
  language?: 'ja' | 'en' | 'both'
}

/**
 * 设计稿页面列表
 * 根据设计稿文件名和可能的页面类型进行分类
 */
export const designPages: DesignPage[] = [
  { id: 1, filename: '1.png', description: '首页/欢迎页', pageType: 'home', language: 'both' },
  { id: 2, filename: '2.png', description: '配置器主页面', pageType: 'configurator', language: 'both' },
  { id: 3, filename: '3.png', description: '配置步骤1', pageType: 'configurator', language: 'both' },
  { id: 4, filename: '4.png', description: '配置步骤2', pageType: 'configurator', language: 'both' },
  // 可以根据实际设计稿添加更多页面
]

/**
 * 获取设计稿路径
 */
export function getDesignImagePath(filename: string): string {
  return `/页面design/${filename}`
}

/**
 * 根据页面类型获取相关设计稿
 */
export function getDesignsByPageType(pageType: DesignPage['pageType']): DesignPage[] {
  return designPages.filter(page => page.pageType === pageType)
}

# 设计系统文档

## 设计稿参考

设计稿文件位于 `页面design/` 目录，包含98个PNG设计稿文件。

## 设计规范

### 颜色系统

#### 主色调 (Primary)
- Primary 50-900: 蓝色系，用于主要操作和强调

#### 次要色 (Secondary)
- Secondary 50-900: 灰色系，用于文本和背景

### 字体

- 日文: Meiryo, Yu Gothic, Hiragino Sans
- 英文: Segoe UI
- 等宽字体: source-code-pro, Menlo, Monaco

### 间距系统

使用Tailwind的间距系统：
- 基础单位: 0.25rem (4px)
- 常用间距: 4, 8, 12, 16, 20, 24, 32, 40, 48, 64

### 组件规范

#### 按钮 (Button)
- 主要按钮: `btn-primary`
- 次要按钮: `btn-secondary`
- 轮廓按钮: `btn-outline`

#### 输入框 (Input)
- 基础样式: `input`
- 支持focus状态和验证状态

#### 卡片 (Card)
- 基础样式: `card`
- 包含阴影和边框

## UI组件库

所有可复用组件位于 `src/components/ui/` 目录。

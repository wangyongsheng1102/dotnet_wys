import React from 'react'
import { useTranslation } from 'react-i18next'
import { Link } from 'react-router-dom'
import { Card, Button } from '../components/ui'
import DesignReference from '../components/DesignReference'

const HomePage: React.FC = () => {
  const { t } = useTranslation()

  return (
    <div className="max-w-7xl mx-auto">
      {/* 设计稿参考 - 仅在开发环境显示 */}
      <DesignReference designFile="1.png" alt="首页设计稿" />

      {/* 根据设计稿1.png实现的首页 */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          {t('app.welcome')}
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          {t('app.description')}
        </p>
      </div>

      {/* 功能卡片区域 - 根据设计稿布局 */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <Card 
          title={t('home.features.configuration')}
          className="hover:shadow-lg transition-shadow"
        >
          <p className="text-gray-600 mb-4">
            {t('home.features.configurationDesc')}
          </p>
          <Link to="/configurator">
            <Button variant="primary" className="w-full">
              {t('configurator.create')}
            </Button>
          </Link>
        </Card>

        <Card 
          title={t('home.features.multilanguage')}
          className="hover:shadow-lg transition-shadow"
        >
          <p className="text-gray-600 mb-4">
            {t('home.features.multilanguageDesc')}
          </p>
          <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
            <span className="px-2 py-1 bg-primary-100 text-primary-700 rounded">日本語</span>
            <span>•</span>
            <span className="px-2 py-1 bg-primary-100 text-primary-700 rounded">English</span>
          </div>
        </Card>

        <Card 
          title={t('home.features.support')}
          className="hover:shadow-lg transition-shadow"
        >
          <p className="text-gray-600 mb-4">
            {t('home.features.supportDesc')}
          </p>
          <Button variant="outline" className="w-full">
            {t('home.learnMore')}
          </Button>
        </Card>
      </div>

      {/* 快速开始指南 - 根据设计稿 */}
      <Card title={t('home.quickStart')} className="mb-8">
        <ol className="list-decimal list-inside space-y-3 text-gray-700">
          <li>{t('home.steps.step1')}</li>
          <li>{t('home.steps.step2')}</li>
          <li>{t('home.steps.step3')}</li>
        </ol>
      </Card>

      {/* 主要操作按钮 - 根据设计稿 */}
      <div className="text-center">
        <Link to="/configurator">
          <Button variant="primary" size="lg" className="px-8 py-4 text-lg">
            {t('home.startConfiguring')}
          </Button>
        </Link>
      </div>
    </div>
  )
}

export default HomePage

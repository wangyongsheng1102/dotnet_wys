import React, { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useNavigate } from 'react-router-dom'
import { configuratorService } from '../services/api'
import { Card, Textarea, Select, Button } from '../components/ui'
import DesignReference from '../components/DesignReference'

const ConfiguratorPage: React.FC = () => {
  const { t, i18n } = useTranslation()
  const navigate = useNavigate()
  const [productType, setProductType] = useState('')
  const [parameters, setParameters] = useState<Record<string, any>>({})
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [currentStep, setCurrentStep] = useState(1)

  const productTypes = [
    { value: 'vts1', label: 'VTS Type 1' },
    { value: 'vts2', label: 'VTS Type 2' },
    { value: 'vts3', label: 'VTS Type 3' },
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setErrors({})
    setLoading(true)
    
    try {
      const response = await configuratorService.createConfiguration({
        product_type: productType,
        parameters,
        language: i18n.language,
      })
      setResult(response)
      setCurrentStep(3) // 跳转到结果页面
    } catch (error: any) {
      console.error('Error creating configuration:', error)
      if (error.response?.data?.detail) {
        setErrors({ submit: error.response.data.detail })
      } else {
        setErrors({ submit: t('common.error') })
      }
    } finally {
      setLoading(false)
    }
  }

  const handleReset = () => {
    setProductType('')
    setParameters({})
    setResult(null)
    setErrors({})
    setCurrentStep(1)
  }

  const handleNext = () => {
    if (currentStep === 1 && productType) {
      setCurrentStep(2)
    }
  }

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  return (
    <div className="max-w-7xl mx-auto">
      {/* 设计稿参考 - 根据当前步骤显示不同的设计稿 */}
      {currentStep === 1 && <DesignReference designFile="3.png" alt="配置步骤1设计稿" />}
      {currentStep === 2 && <DesignReference designFile="4.png" alt="配置步骤2设计稿" />}
      {currentStep === 3 && <DesignReference designFile="2.png" alt="配置结果设计稿" />}

      {/* 步骤指示器 - 根据设计稿 */}
      <div className="mb-8">
        <div className="flex items-center justify-center space-x-4">
          <div className={`flex items-center ${currentStep >= 1 ? 'text-primary-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              currentStep >= 1 ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-500'
            }`}>
              1
            </div>
            <span className="ml-2 font-medium">{t('configurator.step1')}</span>
          </div>
          <div className={`w-16 h-0.5 ${currentStep >= 2 ? 'bg-primary-600' : 'bg-gray-200'}`} />
          <div className={`flex items-center ${currentStep >= 2 ? 'text-primary-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              currentStep >= 2 ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-500'
            }`}>
              2
            </div>
            <span className="ml-2 font-medium">{t('configurator.step2')}</span>
          </div>
          <div className={`w-16 h-0.5 ${currentStep >= 3 ? 'bg-primary-600' : 'bg-gray-200'}`} />
          <div className={`flex items-center ${currentStep >= 3 ? 'text-primary-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              currentStep >= 3 ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-500'
            }`}>
              3
            </div>
            <span className="ml-2 font-medium">{t('configurator.step3')}</span>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          {t('configurator.title')}
        </h1>
        <p className="text-gray-600">
          {t('configurator.description')}
        </p>
      </div>

      {/* 步骤1: 选择产品类型 */}
      {currentStep === 1 && (
        <Card title={t('configurator.step1Title')}>
          <form onSubmit={(e) => { e.preventDefault(); handleNext(); }} className="space-y-6">
            <Select
              label={t('configurator.productType')}
              options={productTypes}
              value={productType}
              onChange={(e) => setProductType(e.target.value)}
              error={errors.productType}
              required
            />
            <div className="flex gap-4 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate('/')}
              >
                {t('configurator.cancel')}
              </Button>
              <Button
                type="submit"
                variant="primary"
                disabled={!productType}
                className="ml-auto"
              >
                {t('common.next')}
              </Button>
            </div>
          </form>
        </Card>
      )}

      {/* 步骤2: 配置参数 */}
      {currentStep === 2 && (
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card title={t('configurator.step2Title')}>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {t('configurator.parameters')}
                  </label>
                  <Textarea
                    value={JSON.stringify(parameters, null, 2)}
                    onChange={(e) => {
                      try {
                        const parsed = JSON.parse(e.target.value)
                        setParameters(parsed)
                        if (errors.parameters) {
                          setErrors({ ...errors, parameters: '' })
                        }
                      } catch (err) {
                        setErrors({ ...errors, parameters: t('configurator.invalidJson') })
                      }
                    }}
                    rows={12}
                    placeholder='{"key": "value"}'
                    error={errors.parameters}
                    helperText={t('configurator.parametersHelper')}
                  />
                </div>

                {errors.submit && (
                  <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                    {errors.submit}
                  </div>
                )}

                <div className="flex gap-4 pt-4">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={handleBack}
                  >
                    {t('common.back')}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleReset}
                  >
                    {t('configurator.reset')}
                  </Button>
                  <Button
                    type="submit"
                    variant="primary"
                    isLoading={loading}
                    disabled={loading}
                    className="ml-auto"
                  >
                    {t('configurator.save')}
                  </Button>
                </div>
              </form>
            </Card>
          </div>

          <div className="lg:col-span-1">
            <Card title={t('configurator.info')}>
              <div className="space-y-4 text-sm text-gray-600">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">
                    {t('configurator.infoTitle')}
                  </h4>
                  <p>{t('configurator.infoDescription')}</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">
                    {t('configurator.parametersTitle')}
                  </h4>
                  <p>{t('configurator.parametersDescription')}</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* 步骤3: 显示结果 */}
      {currentStep === 3 && result && (
        <Card title={t('configurator.result')}>
          <div className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <span className="text-sm font-medium text-gray-700">
                  {t('configurator.configurationId')}:
                </span>
                <span className="ml-2 text-sm text-gray-900 font-mono">
                  {result.configuration_id}
                </span>
              </div>
              <div>
                <span className="text-sm font-medium text-gray-700">
                  {t('configurator.status')}:
                </span>
                <span className={`ml-2 text-sm font-medium ${
                  result.status === 'success' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {result.status}
                </span>
              </div>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-2">
                {t('configurator.resultDetails')}:
              </h4>
              <pre className="bg-gray-50 p-4 rounded-lg overflow-auto text-xs border border-gray-200">
                {JSON.stringify(result.result, null, 2)}
              </pre>
            </div>
            <div className="flex gap-4 pt-4">
              <Button
                variant="primary"
                onClick={() => {
                  handleReset()
                  setCurrentStep(1)
                }}
              >
                {t('configurator.createNew')}
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate('/')}
              >
                {t('common.backToHome')}
              </Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  )
}

export default ConfiguratorPage

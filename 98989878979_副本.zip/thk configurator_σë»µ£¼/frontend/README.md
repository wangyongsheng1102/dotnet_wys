# THK VTS Configurator Frontend

React + TypeScript前端应用

## 安装

```bash
npm install
```

## 运行

```bash
npm run dev
```

应用将在 http://localhost:3000 运行

## 构建

```bash
npm run build
```

## 技术栈

- React 18
- TypeScript
- Vite
- React Router
- react-i18next (国际化)
- Axios (HTTP客户端)

## 项目结构

```
src/
├── components/     # 可复用组件
├── pages/          # 页面组件
├── services/       # API服务
├── i18n/           # 国际化配置
├── types/          # TypeScript类型
└── utils/          # 工具函数
```

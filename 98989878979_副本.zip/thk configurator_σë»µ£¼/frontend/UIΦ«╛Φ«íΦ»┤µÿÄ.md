# UI设计说明

## 设计稿参考

设计稿文件位于项目根目录的 `页面design/` 文件夹，包含98个PNG设计稿文件（1.png - 98.png）。

## 已实现的UI组件

### 基础组件 (`src/components/ui/`)

1. **Button** - 按钮组件
   - 支持多种变体：primary, secondary, outline, danger
   - 支持多种尺寸：sm, md, lg
   - 支持加载状态

2. **Input** - 输入框组件
   - 支持标签、错误提示、帮助文本
   - 自动错误状态样式

3. **Textarea** - 文本域组件
   - 与Input相同的功能特性

4. **Select** - 下拉选择组件
   - 支持选项列表
   - 支持错误提示

5. **Card** - 卡片组件
   - 支持标题和页脚
   - 统一的阴影和边框样式

### 布局组件

1. **Layout** - 主布局组件
   - 响应式导航栏
   - 语言切换器集成
   - 页脚

2. **LanguageSwitcher** - 语言切换组件
   - 日英双语切换
   - 当前语言高亮

## 页面设计

### 首页 (HomePage)
- 欢迎标题和描述
- 功能卡片展示
- 快速开始指南

### 配置器页面 (ConfiguratorPage)
- 左侧：配置表单（2/3宽度）
- 右侧：信息面板（1/3宽度）
- 结果展示区域

## 设计系统

### 颜色
- **Primary**: 蓝色系（#0ea5e9）
- **Secondary**: 灰色系（#64748b）
- **Success**: 绿色（用于成功状态）
- **Error**: 红色（用于错误状态）

### 字体
- 日文：Meiryo, Yu Gothic, Hiragino Sans
- 英文：Segoe UI
- 等宽：source-code-pro, Menlo, Monaco

### 间距
- 使用Tailwind的间距系统
- 基础单位：4px (0.25rem)

## 响应式设计

- **移动端**: < 640px
- **平板**: 640px - 1024px
- **桌面**: > 1024px

使用Tailwind的响应式前缀：
- `sm:` - 640px+
- `md:` - 768px+
- `lg:` - 1024px+
- `xl:` - 1280px+

## 下一步工作

1. 查看设计稿文件，提取具体的UI设计细节
2. 根据设计稿调整颜色、字体、间距
3. 实现设计稿中的特定组件
4. 优化响应式布局
5. 添加动画和过渡效果

## 使用示例

```tsx
import { Button, Input, Card } from '../components/ui'

function MyComponent() {
  return (
    <Card title="标题">
      <Input label="输入框" />
      <Button variant="primary">按钮</Button>
    </Card>
  )
}
```

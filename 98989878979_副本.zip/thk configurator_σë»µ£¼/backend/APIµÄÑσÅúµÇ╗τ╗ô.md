# THK VTS Configurator API 接口总结

## 认证相关 API (`/api/v1/auth`)

### 1. 用户登录
**端点**: `POST /api/v1/auth/login`

**请求体**:
```json
{
  "email": "user@example.com",
  "password": "Password123"
}
```

**响应**:
```json
{
  "access_token": "eyJ...",
  "refresh_token": "eyJ...",
  "token_type": "bearer",
  "expires_in": 1800
}
```

**说明**: 使用email和密码登录，返回JWT令牌

---

### 2. 新用户注册（两步流程）

#### 第一步：请求注册
**端点**: `POST /api/v1/auth/register/request`

**请求体**:
```json
{
  "email": "user@example.com",
  "confirm_email": "user@example.com",
  "username": "user123"
}
```

**响应**:
```json
{
  "message": "Registration email sent. Please check your email to complete registration.",
  "email": "user@example.com"
}
```

**说明**: 输入两次email和用户名，系统发送注册邮件

#### 第二步：完成注册
**端点**: `POST /api/v1/auth/register/complete`

**请求体**:
```json
{
  "token": "token-from-email",
  "password": "Password123",
  "confirm_password": "Password123"
}
```

**响应**: 用户信息（UserResponse）

**说明**: 通过邮件链接进入，设置密码完成注册

---

### 3. 密码重置（两步流程）

#### 第一步：请求密码重置
**端点**: `POST /api/v1/auth/password/reset/request`

**请求体**:
```json
{
  "email": "user@example.com"
}
```

**响应**:
```json
{
  "message": "If the email exists, a password reset link has been sent.",
  "email": "user@example.com"
}
```

**说明**: 输入邮箱，系统发送密码重置邮件（24小时有效）

#### 第二步：确认密码重置
**端点**: `POST /api/v1/auth/password/reset/confirm`

**请求体**:
```json
{
  "token": "token-from-email",
  "new_password": "NewPassword123",
  "confirm_password": "NewPassword123"
}
```

**响应**:
```json
{
  "message": "Password reset successfully",
  "user_id": 1
}
```

**说明**: 通过邮件链接进入，输入两次新密码重置密码

---

### 4. 刷新令牌
**端点**: `POST /api/v1/auth/refresh`

**请求体**:
```json
{
  "refresh_token": "refresh-token-string"
}
```

**响应**: 新的Token对象

**说明**: 使用刷新令牌获取新的访问令牌

---

### 5. 获取当前用户信息
**端点**: `GET /api/v1/auth/me`

**需要认证**: ✅

**响应**: 用户信息（UserResponse）

---

### 6. 更新个人资料
**端点**: `PUT /api/v1/auth/me`

**需要认证**: ✅

**请求体**:
```json
{
  "username": "newusername",
  "full_name": "New Name",
  "language": "en"
}
```

**响应**: 更新后的用户信息

**说明**: 可以修改用户名、全名、语言偏好

---

### 7. 修改密码
**端点**: `POST /api/v1/auth/password/change`

**需要认证**: ✅

**请求体**:
```json
{
  "current_password": "OldPassword123",
  "new_password": "NewPassword123",
  "confirm_password": "NewPassword123"
}
```

**响应**:
```json
{
  "message": "Password changed successfully"
}
```

**说明**: 需要提供当前密码进行验证

---

## 配置器相关 API (`/api/v1/configurator`)

### 1. 创建配置
**端点**: `POST /api/v1/configurator/create`

**需要认证**: ✅  
**权限要求**: engineer+

**请求体**: ConfigurationCreate

**响应**: ConfigurationResponse

---

### 2. 获取配置详情
**端点**: `GET /api/v1/configurator/{configuration_id}`

**需要认证**: ✅  
**权限要求**: viewer+ (只能查看自己的配置，admin可查看所有)

---

### 3. 获取配置列表
**端点**: `GET /api/v1/configurator/`

**需要认证**: ✅  
**权限要求**: viewer+

**查询参数**:
- `page`: 页码（默认1）
- `page_size`: 每页数量（默认20，最大100）
- `status`: 配置状态（可选）
- `product_type`: 产品类型（可选）

---

### 4. 更新配置
**端点**: `PUT /api/v1/configurator/{configuration_id}`

**需要认证**: ✅  
**权限要求**: engineer+ (只能更新自己的配置)

---

### 5. 删除配置
**端点**: `DELETE /api/v1/configurator/{configuration_id}`

**需要认证**: ✅  
**权限要求**: engineer+ (只能删除自己的配置)

---

### 6. 批准配置
**端点**: `POST /api/v1/configurator/{configuration_id}/approve`

**需要认证**: ✅  
**权限要求**: admin

---

## 产品相关 API (`/api/v1/products`)

### 1. 获取产品列表
**端点**: `GET /api/v1/products`

**需要认证**: ❌ (公开接口)

**查询参数**:
- `product_type`: 产品类型（可选）
- `is_active`: 是否激活（可选）
- `is_available`: 是否可用（可选）

---

### 2. 获取产品详情
**端点**: `GET /api/v1/products/{product_id}`

**需要认证**: ❌ (公开接口)

---

### 3. 获取产品参数定义
**端点**: `GET /api/v1/products/{product_id}/parameters`

**需要认证**: ❌ (公开接口)

---

## 国际化相关 API (`/api/v1/i18n`)

### 获取翻译文本
**端点**: `GET /api/v1/i18n/translations/{language}`

**需要认证**: ❌ (公开接口)

**路径参数**:
- `language`: 语言代码（ja/en）

---

## 用户管理 API (`/api/v1/users`)

### 1. 获取用户列表
**端点**: `GET /api/v1/users`

**需要认证**: ✅  
**权限要求**: admin

---

### 2. 获取用户详情
**端点**: `GET /api/v1/users/{user_id}`

**需要认证**: ✅  
**权限要求**: admin或自己

---

### 3. 更新用户信息
**端点**: `PUT /api/v1/users/{user_id}`

**需要认证**: ✅  
**权限要求**: admin或自己

---

### 4. 删除用户
**端点**: `DELETE /api/v1/users/{user_id}`

**需要认证**: ✅  
**权限要求**: admin

---

## 认证方式

所有需要认证的接口都需要在请求头中包含JWT令牌：

```
Authorization: Bearer <access_token>
```

## 错误响应格式

```json
{
  "detail": "Error message"
}
```

## 状态码

- `200 OK`: 成功
- `201 Created`: 创建成功
- `204 No Content`: 删除成功
- `400 Bad Request`: 请求参数错误
- `401 Unauthorized`: 未认证或认证失败
- `403 Forbidden`: 权限不足
- `404 Not Found`: 资源不存在
- `500 Internal Server Error`: 服务器错误

"""
权限控制
"""
from functools import wraps
from typing import List, Optional
from fastapi import HTTPException, status, Depends
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.user import User, UserRole
from app.models.configuration import Configuration
from app.core.security import decode_token
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

security = HTTPBearer()


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
) -> User:
    """获取当前用户"""
    token = credentials.credentials
    payload = decode_token(token)
    user_id: int = payload.get("sub")
    
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
        )
    
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
        )
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User is inactive",
        )
    
    return user


def require_roles(allowed_roles: List[UserRole]):
    """要求特定角色的装饰器"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            current_user: User = kwargs.get("current_user")
            if not current_user:
                # 尝试从args中获取
                for arg in args:
                    if isinstance(arg, User):
                        current_user = arg
                        break
            
            if not current_user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Authentication required",
                )
            
            if current_user.role not in allowed_roles:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Required roles: {[role.value for role in allowed_roles]}",
                )
            
            return await func(*args, **kwargs)
        return wrapper
    return decorator


def check_permission(user: User, resource: str, action: str) -> bool:
    """
    检查用户权限
    resource: 资源类型 (configuration, user, product, etc.)
    action: 操作类型 (create, read, update, delete, approve, etc.)
    """
    # 管理员拥有所有权限
    if user.role == UserRole.ADMIN:
        return True
    
    # 工程师可以创建、读取、更新配置
    if user.role == UserRole.ENGINEER:
        if resource == "configuration":
            return action in ["create", "read", "update", "delete"]
        if resource == "product":
            return action in ["read"]
    
    # 查看者只能读取
    if user.role == UserRole.VIEWER:
        return action == "read"
    
    # 访客只能读取公开资源
    if user.role == UserRole.GUEST:
        return action == "read" and resource == "product"
    
    return False


def check_ownership(user: User, resource: Configuration) -> bool:
    """检查资源所有权"""
    if user.role == UserRole.ADMIN:
        return True
    return resource.user_id == user.id

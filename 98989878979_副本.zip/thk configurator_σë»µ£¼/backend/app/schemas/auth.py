"""
认证相关的Pydantic模式
"""
from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional


class LoginRequest(BaseModel):
    """登录请求"""
    email: EmailStr
    password: str


class PasswordResetRequest(BaseModel):
    """密码重置请求（第一步：输入邮箱）"""
    email: EmailStr


class PasswordResetConfirm(BaseModel):
    """密码重置确认（第二步：设置新密码）"""
    token: str
    new_password: str = Field(..., min_length=8)
    confirm_password: str = Field(..., min_length=8)
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        if 'new_password' in values and v != values['new_password']:
            raise ValueError('Passwords do not match')
        return v


class RegistrationRequest(BaseModel):
    """用户注册请求（第一步：输入邮箱和用户名）"""
    email: EmailStr
    confirm_email: EmailStr
    username: str = Field(..., min_length=3, max_length=50)
    
    @validator('confirm_email')
    def emails_match(cls, v, values):
        if 'email' in values and v != values['email']:
            raise ValueError('Emails do not match')
        return v


class RegistrationComplete(BaseModel):
    """完成注册（第二步：设置密码）"""
    token: str
    password: str = Field(..., min_length=8)
    confirm_password: str = Field(..., min_length=8)
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        if 'password' in values and v != values['password']:
            raise ValueError('Passwords do not match')
        return v


class ChangePasswordRequest(BaseModel):
    """修改密码请求"""
    current_password: str
    new_password: str = Field(..., min_length=8)
    confirm_password: str = Field(..., min_length=8)
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        if 'new_password' in values and v != values['new_password']:
            raise ValueError('Passwords do not match')
        return v


class UpdateProfileRequest(BaseModel):
    """更新个人资料请求"""
    username: Optional[str] = Field(None, min_length=3, max_length=50)
    full_name: Optional[str] = Field(None, max_length=100)
    language: Optional[str] = Field(None, pattern="^(ja|en)$")


class RefreshTokenRequest(BaseModel):
    """刷新令牌请求"""
    refresh_token: str

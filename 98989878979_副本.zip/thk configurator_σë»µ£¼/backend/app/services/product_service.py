"""
产品服务
"""
from sqlalchemy.orm import Session
from typing import Optional, List
from app.models.product import Product, ProductType


class ProductService:
    """产品业务逻辑服务"""
    
    @staticmethod
    def get_product_by_id(db: Session, product_id: int) -> Optional[Product]:
        """根据ID获取产品"""
        return db.query(Product).filter(Product.id == product_id).first()
    
    @staticmethod
    def get_product_by_code(db: Session, product_code: str) -> Optional[Product]:
        """根据产品代码获取产品"""
        return db.query(Product).filter(Product.product_code == product_code).first()
    
    @staticmethod
    def get_products(
        db: Session,
        product_type: Optional[ProductType] = None,
        is_active: Optional[bool] = True,
        is_available: Optional[bool] = True
    ) -> List[Product]:
        """获取产品列表"""
        query = db.query(Product)
        
        if product_type:
            query = query.filter(Product.product_type == product_type)
        if is_active is not None:
            query = query.filter(Product.is_active == is_active)
        if is_available is not None:
            query = query.filter(Product.is_available == is_available)
        
        return query.order_by(Product.product_code).all()
    
    @staticmethod
    def get_parameter_definitions(
        db: Session,
        product_id: int
    ) -> Optional[dict]:
        """获取产品的参数定义"""
        product = ProductService.get_product_by_id(db, product_id)
        if product:
            return product.parameter_definitions
        return None

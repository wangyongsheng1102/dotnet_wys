"""
配置服务
"""
import uuid
from sqlalchemy.orm import Session
from typing import Optional, List, Dict, Any
from datetime import datetime
from app.models.configuration import Configuration, ConfigurationStatus
from app.models.user import User
from app.core.permissions import check_permission, check_ownership


class ConfigurationService:
    """配置业务逻辑服务"""
    
    @staticmethod
    def generate_configuration_id() -> str:
        """生成配置ID"""
        return f"CONF-{uuid.uuid4().hex[:12].upper()}"
    
    @staticmethod
    def create_configuration(
        db: Session,
        user: User,
        product_type: str,
        parameters: Dict[str, Any],
        language: str = "ja",
        name: Optional[str] = None,
        description: Optional[str] = None,
        notes: Optional[str] = None
    ) -> Configuration:
        """创建配置"""
        # 检查权限
        if not check_permission(user, "configuration", "create"):
            raise PermissionError("User does not have permission to create configurations")
        
        # 生成配置ID
        configuration_id = ConfigurationService.generate_configuration_id()
        
        # 创建配置
        configuration = Configuration(
            configuration_id=configuration_id,
            user_id=user.id,
            product_type=product_type,
            parameters=parameters,
            language=language,
            name=name or f"Configuration {configuration_id}",
            description=description,
            notes=notes,
            status=ConfigurationStatus.DRAFT,
        )
        
        db.add(configuration)
        db.commit()
        db.refresh(configuration)
        
        # 计算配置结果（这里可以添加业务逻辑）
        result = ConfigurationService.calculate_result(configuration)
        configuration.result = result
        db.commit()
        db.refresh(configuration)
        
        return configuration
    
    @staticmethod
    def calculate_result(configuration: Configuration) -> Dict[str, Any]:
        """
        计算配置结果
        这里应该根据产品类型和参数进行实际的计算逻辑
        """
        # TODO: 根据实际业务需求实现计算逻辑
        return {
            "message": "Configuration calculated successfully",
            "configuration_id": configuration.configuration_id,
            "calculated_at": datetime.utcnow().isoformat(),
        }
    
    @staticmethod
    def get_configuration(
        db: Session,
        configuration_id: str,
        user: Optional[User] = None
    ) -> Optional[Configuration]:
        """获取配置"""
        configuration = db.query(Configuration).filter(
            Configuration.configuration_id == configuration_id
        ).first()
        
        if not configuration:
            return None
        
        # 检查权限
        if user:
            if not check_permission(user, "configuration", "read"):
                raise PermissionError("User does not have permission to read configurations")
            # 非管理员只能查看自己的配置
            if user.role.value != "admin" and not check_ownership(user, configuration):
                raise PermissionError("User can only view their own configurations")
        
        return configuration
    
    @staticmethod
    def list_configurations(
        db: Session,
        user: User,
        skip: int = 0,
        limit: int = 20,
        status: Optional[ConfigurationStatus] = None,
        product_type: Optional[str] = None
    ) -> tuple[List[Configuration], int]:
        """获取配置列表"""
        if not check_permission(user, "configuration", "read"):
            raise PermissionError("User does not have permission to list configurations")
        
        query = db.query(Configuration)
        
        # 非管理员只能查看自己的配置
        if user.role.value != "admin":
            query = query.filter(Configuration.user_id == user.id)
        
        if status:
            query = query.filter(Configuration.status == status)
        if product_type:
            query = query.filter(Configuration.product_type == product_type)
        
        total = query.count()
        configurations = query.order_by(Configuration.created_at.desc()).offset(skip).limit(limit).all()
        
        return configurations, total
    
    @staticmethod
    def update_configuration(
        db: Session,
        configuration: Configuration,
        user: User,
        update_data: Dict[str, Any]
    ) -> Configuration:
        """更新配置"""
        # 检查权限
        if not check_permission(user, "configuration", "update"):
            raise PermissionError("User does not have permission to update configurations")
        
        # 检查所有权
        if not check_ownership(user, configuration):
            raise PermissionError("User can only update their own configurations")
        
        # 更新数据
        for key, value in update_data.items():
            if hasattr(configuration, key):
                setattr(configuration, key, value)
        
        # 如果参数更新，重新计算结果
        if "parameters" in update_data:
            result = ConfigurationService.calculate_result(configuration)
            configuration.result = result
        
        db.commit()
        db.refresh(configuration)
        
        return configuration
    
    @staticmethod
    def delete_configuration(
        db: Session,
        configuration: Configuration,
        user: User
    ) -> bool:
        """删除配置"""
        # 检查权限
        if not check_permission(user, "configuration", "delete"):
            raise PermissionError("User does not have permission to delete configurations")
        
        # 检查所有权
        if not check_ownership(user, configuration):
            raise PermissionError("User can only delete their own configurations")
        
        db.delete(configuration)
        db.commit()
        return True
    
    @staticmethod
    def approve_configuration(
        db: Session,
        configuration: Configuration,
        user: User
    ) -> Configuration:
        """批准配置（需要管理员权限）"""
        if user.role.value != "admin":
            raise PermissionError("Only administrators can approve configurations")
        
        configuration.status = ConfigurationStatus.APPROVED
        configuration.approved_at = datetime.utcnow()
        db.commit()
        db.refresh(configuration)
        
        return configuration

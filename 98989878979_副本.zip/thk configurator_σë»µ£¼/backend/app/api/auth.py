"""
认证相关API
"""
from fastapi import APIRouter, Depends, HTTPException, status, Body
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import (
    verify_password,
    get_password_hash,
    create_access_token,
    create_refresh_token,
    decode_token,
    validate_password,
)
from app.core.config import settings
from app.core.permissions import get_current_user
from app.schemas.user import UserResponse, Token
from app.schemas.auth import (
    LoginRequest,
    PasswordResetRequest,
    PasswordResetConfirm,
    RegistrationRequest,
    RegistrationComplete,
    ChangePasswordRequest,
    UpdateProfileRequest,
    RefreshTokenRequest,
)
from app.models.user import User, UserRole
from app.services.auth_service import AuthService

router = APIRouter()


@router.post("/login", response_model=Token)
async def login(
    login_data: LoginRequest,
    db: Session = Depends(get_db)
):
    """
    用户登录（使用email和密码）
    成功后返回JWT令牌
    """
    # 根据email查找用户
    user = AuthService.get_user_by_email(db, login_data.email)
    
    if not user or not verify_password(login_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User is inactive",
        )
    
    # 更新最后登录时间
    from datetime import datetime
    user.last_login = datetime.utcnow()
    db.commit()
    
    # 创建令牌
    access_token = create_access_token(data={"sub": user.id, "username": user.username})
    refresh_token = create_refresh_token(data={"sub": user.id, "username": user.username})
    
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    }


@router.post("/register/request", status_code=status.HTTP_200_OK)
async def request_registration(
    registration_data: RegistrationRequest,
    db: Session = Depends(get_db)
):
    """
    新用户注册请求（第一步）
    输入两次email和用户名，发送验证邮件
    """
    try:
        await AuthService.request_registration(
            db=db,
            email=registration_data.email,
            username=registration_data.username,
            language="ja"  # 可以根据请求头或参数确定语言
        )
        return {
            "message": "Registration email sent. Please check your email to complete registration.",
            "email": registration_data.email
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error sending registration email: {str(e)}",
        )


@router.post("/register/complete", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def complete_registration(
    registration_data: RegistrationComplete,
    db: Session = Depends(get_db)
):
    """
    完成用户注册（第二步）
    通过邮件链接进入，设置密码后完成注册
    """
    try:
        user = await AuthService.complete_registration(
            db=db,
            token=registration_data.token,
            password=registration_data.password
        )
        return user
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error completing registration: {str(e)}",
        )


@router.post("/password/reset/request", status_code=status.HTTP_200_OK)
async def request_password_reset(
    reset_data: PasswordResetRequest,
    db: Session = Depends(get_db)
):
    """
    请求密码重置（第一步）
    输入邮箱，发送重置密码邮件
    """
    try:
        await AuthService.request_password_reset(
            db=db,
            email=reset_data.email,
            language="ja"  # 可以根据请求头或参数确定语言
        )
        # 为了安全，即使用户不存在也返回成功消息
        return {
            "message": "If the email exists, a password reset link has been sent.",
            "email": reset_data.email
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error sending password reset email: {str(e)}",
        )


@router.post("/password/reset/confirm", status_code=status.HTTP_200_OK)
async def confirm_password_reset(
    reset_data: PasswordResetConfirm,
    db: Session = Depends(get_db)
):
    """
    确认密码重置（第二步）
    通过邮件链接进入，输入两次新密码后重置密码
    """
    try:
        user = await AuthService.reset_password(
            db=db,
            token=reset_data.token,
            new_password=reset_data.new_password
        )
        if not user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid or expired reset token",
            )
        return {
            "message": "Password reset successfully",
            "user_id": user.id
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error resetting password: {str(e)}",
        )


@router.post("/refresh", response_model=Token)
async def refresh_token(
    token_data: RefreshTokenRequest,
    db: Session = Depends(get_db)
):
    """
    刷新访问令牌
    请求体: {"refresh_token": "token-string"}
    """
    payload = decode_token(token_data.refresh_token)
    
    if payload.get("type") != "refresh":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token type",
        )
    
    user_id = payload.get("sub")
    user = db.query(User).filter(User.id == user_id).first()
    
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive",
        )
    
    # 创建新令牌
    access_token = create_access_token(data={"sub": user.id, "username": user.username})
    new_refresh_token = create_refresh_token(data={"sub": user.id, "username": user.username})
    
    return {
        "access_token": access_token,
        "refresh_token": new_refresh_token,
        "token_type": "bearer",
        "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    }


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(current_user: User = Depends(get_current_user)):
    """
    获取当前用户信息
    """
    return current_user


@router.put("/me", response_model=UserResponse)
async def update_profile(
    profile_data: UpdateProfileRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    更新个人资料（用户名、全名、语言）
    """
    update_data = profile_data.dict(exclude_unset=True)
    
    # 如果更新用户名，检查是否已被使用
    if "username" in update_data and update_data["username"] != current_user.username:
        existing_user = AuthService.get_user_by_username(db, update_data["username"])
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username already taken",
            )
    
    for field, value in update_data.items():
        setattr(current_user, field, value)
    
    db.commit()
    db.refresh(current_user)
    
    return current_user


@router.post("/password/change", status_code=status.HTTP_200_OK)
async def change_password(
    password_data: ChangePasswordRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    修改密码
    需要提供当前密码和新密码
    """
    try:
        AuthService.change_password(
            db=db,
            user=current_user,
            current_password=password_data.current_password,
            new_password=password_data.new_password
        )
        return {
            "message": "Password changed successfully"
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error changing password: {str(e)}",
        )

"""
产品API路由
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional

from app.core.database import get_db
from app.models.product import ProductType
from app.schemas.product import ProductResponse, ProductListResponse
from app.services.product_service import ProductService

router = APIRouter()


@router.get("/", response_model=ProductListResponse)
async def list_products(
    product_type: Optional[ProductType] = Query(None, description="产品类型"),
    is_active: Optional[bool] = Query(True, description="是否激活"),
    is_available: Optional[bool] = Query(True, description="是否可用"),
    db: Session = Depends(get_db)
):
    """
    获取产品列表
    公开接口，不需要认证
    """
    products = ProductService.get_products(
        db=db,
        product_type=product_type,
        is_active=is_active,
        is_available=is_available
    )
    return {
        "total": len(products),
        "items": products,
    }


@router.get("/{product_id}", response_model=ProductResponse)
async def get_product(
    product_id: int,
    db: Session = Depends(get_db)
):
    """
    获取产品详情
    公开接口，不需要认证
    """
    product = ProductService.get_product_by_id(db, product_id)
    if not product:
        from fastapi import HTTPException, status
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found",
        )
    return product


@router.get("/{product_id}/parameters", response_model=dict)
async def get_product_parameters(
    product_id: int,
    db: Session = Depends(get_db)
):
    """
    获取产品的参数定义
    公开接口，不需要认证
    """
    parameters = ProductService.get_parameter_definitions(db, product_id)
    if parameters is None:
        from fastapi import HTTPException, status
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found",
        )
    return {"parameters": parameters}

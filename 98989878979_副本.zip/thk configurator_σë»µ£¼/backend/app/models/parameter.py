"""
参数模型（用于参数模板和验证）
"""
from sqlalchemy import Column, Integer, String, JSON, DateTime, Boolean, Text, ForeignKey, Float
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.core.database import Base


class Parameter(Base):
    """参数定义模型"""
    __tablename__ = "parameters"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    parameter_key = Column(String(100), nullable=False, index=True)  # 参数键
    parameter_name_ja = Column(String(200), nullable=False)  # 日语参数名
    parameter_name_en = Column(String(200), nullable=False)  # 英语参数名
    
    # 参数类型和验证规则
    parameter_type = Column(String(50), nullable=False)  # string, number, boolean, select, etc.
    default_value = Column(JSON, nullable=True)  # 默认值
    validation_rules = Column(JSON, nullable=True)  # 验证规则（min, max, required, etc.）
    options = Column(JSON, nullable=True)  # 选项（用于select类型）
    
    # 元数据
    description_ja = Column(Text, nullable=True)
    description_en = Column(Text, nullable=True)
    unit = Column(String(20), nullable=True)  # 单位（如 mm, kg, etc.）
    order = Column(Integer, default=0, nullable=False)  # 显示顺序
    
    # 状态
    is_required = Column(Boolean, default=False, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    
    # 时间戳
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # 关系
    product = relationship("Product")

    def __repr__(self):
        return f"<Parameter(id={self.id}, parameter_key={self.parameter_key})>"


class ParameterValue(Base):
    """参数值模型（用于存储配置的参数值）"""
    __tablename__ = "parameter_values"

    id = Column(Integer, primary_key=True, index=True)
    configuration_id = Column(Integer, ForeignKey("configurations.id"), nullable=False)
    parameter_id = Column(Integer, ForeignKey("parameters.id"), nullable=False)
    value = Column(JSON, nullable=False)  # 参数值（JSON格式，支持各种类型）
    
    # 时间戳
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # 关系
    configuration = relationship("Configuration")
    parameter = relationship("Parameter")

    def __repr__(self):
        return f"<ParameterValue(id={self.id}, parameter_id={self.parameter_id}, value={self.value})>"

# THK VTS Configurator Backend

FastAPI后端应用，提供完整的RESTful API，包括JWT认证、权限控制和配置管理功能。

## 功能特性

- ✅ JWT认证和授权
- ✅ 基于角色的权限控制（RBAC）
- ✅ PostgreSQL数据库支持
- ✅ 用户管理
- ✅ 配置管理
- ✅ 产品管理
- ✅ 国际化支持
- ✅ API文档（Swagger/ReDoc）

## 技术栈

- Python 3.10+
- FastAPI
- SQLAlchemy (ORM)
- PostgreSQL
- JWT (python-jose)
- Pydantic (数据验证)
- Alembic (数据库迁移)

## 安装

### 1. 创建虚拟环境

```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
```

### 2. 安装依赖

```bash
pip install -r requirements.txt
```

### 3. 配置环境变量

复制 `.env.example` 到 `.env` 并修改配置：

```bash
cp .env.example .env
```

编辑 `.env` 文件，设置数据库连接和其他配置。

### 4. 创建PostgreSQL数据库

```bash
# 使用psql
createdb thk_configurator

# 或使用SQL
psql -U postgres
CREATE DATABASE thk_configurator;
```

### 5. 初始化数据库

```bash
# 运行初始化脚本
python scripts/init_db.py
```

这将创建：
- 数据库表结构
- 默认管理员用户（admin / admin123）
- 示例产品数据

## 运行

```bash
uvicorn app.main:app --reload
```

API文档将在以下地址可用：
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## API端点

### 认证相关 (`/api/v1/auth`)

- `POST /register` - 用户注册
- `POST /login` - 用户登录
- `POST /refresh` - 刷新令牌
- `GET /me` - 获取当前用户信息
- `PUT /me` - 更新当前用户信息

### 配置器相关 (`/api/v1/configurator`)

- `POST /create` - 创建新配置（需要认证）
- `GET /{id}` - 获取配置详情（需要认证）
- `GET /` - 获取配置列表（需要认证）
- `PUT /{id}` - 更新配置（需要认证）
- `DELETE /{id}` - 删除配置（需要认证）
- `POST /{id}/approve` - 批准配置（需要管理员权限）

### 产品相关 (`/api/v1/products`)

- `GET /` - 获取产品列表（公开）
- `GET /{id}` - 获取产品详情（公开）
- `GET /{id}/parameters` - 获取产品参数定义（公开）

### 国际化相关 (`/api/v1/i18n`)

- `GET /translations/{language}` - 获取翻译文本（公开）

## 用户角色

- **admin**: 管理员，拥有所有权限
- **engineer**: 工程师，可以创建和管理配置
- **viewer**: 查看者，只能查看配置
- **guest**: 访客，只能查看公开资源

## 数据库迁移

使用Alembic进行数据库迁移：

```bash
# 初始化Alembic（如果还没有）
alembic init alembic

# 创建迁移
alembic revision --autogenerate -m "Description"

# 应用迁移
alembic upgrade head

# 回滚迁移
alembic downgrade -1
```

## 项目结构

```
backend/
├── app/
│   ├── api/              # API路由
│   │   ├── auth.py       # 认证相关
│   │   ├── configurator.py  # 配置器相关
│   │   ├── products.py   # 产品相关
│   │   └── i18n.py       # 国际化相关
│   ├── core/             # 核心功能
│   │   ├── config.py     # 配置
│   │   ├── database.py   # 数据库连接
│   │   ├── security.py   # 安全相关（JWT、密码）
│   │   └── permissions.py  # 权限控制
│   ├── models/           # 数据库模型
│   │   ├── user.py       # 用户模型
│   │   ├── configuration.py  # 配置模型
│   │   ├── product.py    # 产品模型
│   │   └── parameter.py  # 参数模型
│   ├── schemas/          # Pydantic模式
│   │   ├── user.py
│   │   ├── configuration.py
│   │   ├── product.py
│   │   └── parameter.py
│   ├── services/         # 业务逻辑服务
│   │   ├── user_service.py
│   │   ├── configuration_service.py
│   │   └── product_service.py
│   └── main.py          # 应用入口
├── scripts/              # 工具脚本
│   └── init_db.py       # 数据库初始化
├── alembic.ini          # Alembic配置
├── requirements.txt     # 依赖列表
└── .env.example         # 环境变量示例
```

## 开发

### 运行测试

```bash
pytest
```

### 代码格式化

```bash
black app/
isort app/
```

### 类型检查

```bash
mypy app/
```

## 生产部署

1. 设置强密码的SECRET_KEY
2. 配置生产数据库
3. 设置适当的CORS_ORIGINS
4. 使用生产级WSGI服务器（如Gunicorn）
5. 配置HTTPS
6. 设置适当的日志记录

## 安全注意事项

- 在生产环境中更改默认管理员密码
- 使用强密码策略
- 定期更新依赖
- 配置适当的CORS策略
- 使用HTTPS
- 定期备份数据库

## 详细API文档

参见 [API文档.md](./API文档.md)

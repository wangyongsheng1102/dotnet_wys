"""
数据库初始化脚本
用于创建初始数据（管理员用户、示例产品等）
"""
import sys
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from sqlalchemy.orm import Session
from app.core.database import SessionLocal, engine, Base
from app.models.user import User, UserRole
from app.models.product import Product, ProductType
from app.models.verification_token import VerificationToken
from app.core.security import get_password_hash


def init_database():
    """初始化数据库"""
    # 创建所有表
    Base.metadata.create_all(bind=engine)
    
    db: Session = SessionLocal()
    try:
        # 创建默认管理员用户
        admin_user = db.query(User).filter(User.username == "admin").first()
        if not admin_user:
            admin_user = User(
                username="admin",
                email="admin@thk.com",
                hashed_password=get_password_hash("admin123"),  # 请在生产环境中更改
                full_name="Administrator",
                role=UserRole.ADMIN,
                is_active=True,
                is_verified=True,
                language="ja",
            )
            db.add(admin_user)
            print("✓ 创建默认管理员用户")
            print("  用户名: admin")
            print("  邮箱: admin@thk.com")
            print("  密码: admin123")
            print("  ⚠️  警告: 请在生产环境中立即更改密码！")
        
        # 创建示例产品
        products_data = [
            {
                "product_code": "VTS1-001",
                "product_type": ProductType.VTS1,
                "name_ja": "VTS Type 1 基本型",
                "name_en": "VTS Type 1 Basic",
                "description_ja": "VTS Type 1の基本モデルです",
                "description_en": "Basic model of VTS Type 1",
                "parameter_definitions": {
                    "length": {
                        "type": "number",
                        "min": 100,
                        "max": 1000,
                        "unit": "mm",
                        "required": True,
                    },
                    "width": {
                        "type": "number",
                        "min": 50,
                        "max": 500,
                        "unit": "mm",
                        "required": True,
                    },
                },
            },
            {
                "product_code": "VTS2-001",
                "product_type": ProductType.VTS2,
                "name_ja": "VTS Type 2 標準型",
                "name_en": "VTS Type 2 Standard",
                "description_ja": "VTS Type 2の標準モデルです",
                "description_en": "Standard model of VTS Type 2",
                "parameter_definitions": {
                    "length": {
                        "type": "number",
                        "min": 200,
                        "max": 2000,
                        "unit": "mm",
                        "required": True,
                    },
                    "width": {
                        "type": "number",
                        "min": 100,
                        "max": 1000,
                        "unit": "mm",
                        "required": True,
                    },
                },
            },
            {
                "product_code": "VTS3-001",
                "product_type": ProductType.VTS3,
                "name_ja": "VTS Type 3 高精度型",
                "name_en": "VTS Type 3 High Precision",
                "description_ja": "VTS Type 3の高精度モデルです",
                "description_en": "High precision model of VTS Type 3",
                "parameter_definitions": {
                    "length": {
                        "type": "number",
                        "min": 300,
                        "max": 3000,
                        "unit": "mm",
                        "required": True,
                    },
                    "width": {
                        "type": "number",
                        "min": 150,
                        "max": 1500,
                        "unit": "mm",
                        "required": True,
                    },
                },
            },
        ]
        
        for product_data in products_data:
            existing_product = db.query(Product).filter(
                Product.product_code == product_data["product_code"]
            ).first()
            if not existing_product:
                product = Product(**product_data)
                db.add(product)
                print(f"✓ 创建产品: {product_data['product_code']}")
        
        db.commit()
        print("\n✓ 数据库初始化完成！")
        
    except Exception as e:
        db.rollback()
        print(f"✗ 数据库初始化失败: {str(e)}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    init_database()

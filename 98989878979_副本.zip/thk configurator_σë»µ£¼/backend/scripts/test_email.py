"""
测试邮件发送功能
"""
import asyncio
import sys
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from app.core.email import email_service


async def test_email():
    """测试邮件发送"""
    print("测试邮件发送功能...")
    print(f"SMTP Host: {email_service.smtp_host}")
    print(f"SMTP Port: {email_service.smtp_port}")
    print(f"From Email: {email_service.from_email}")
    print(f"Base URL: {email_service.base_url}")
    print()
    
    # 测试密码重置邮件
    print("1. 测试密码重置邮件...")
    result = await email_service.send_password_reset_email(
        email="test@example.com",
        reset_token="test-reset-token-123",
        language="ja"
    )
    print(f"   结果: {'成功' if result else '失败（可能未配置SMTP）'}")
    print()
    
    # 测试注册邮件
    print("2. 测试注册邮件...")
    result = await email_service.send_registration_email(
        email="test@example.com",
        username="testuser",
        registration_token="test-registration-token-123",
        language="ja"
    )
    print(f"   结果: {'成功' if result else '失败（可能未配置SMTP）'}")
    print()
    
    print("测试完成！")
    print("\n注意: 如果SMTP未配置，邮件不会实际发送，但会在控制台显示邮件内容。")


if __name__ == "__main__":
    asyncio.run(test_email())

# THK VTS Configurator API 文档

## 概述

THK VTS配置器后端API，提供完整的用户认证、权限控制、配置管理等功能。

## 认证

所有需要认证的接口都需要在请求头中包含JWT令牌：

```
Authorization: Bearer <access_token>
```

### 获取令牌

1. **用户注册**
   - `POST /api/v1/auth/register`
   - 创建新用户账户

2. **用户登录**
   - `POST /api/v1/auth/login`
   - 获取访问令牌和刷新令牌

3. **刷新令牌**
   - `POST /api/v1/auth/refresh`
   - 使用刷新令牌获取新的访问令牌

## API端点

### 认证相关 (`/api/v1/auth`)

| 方法 | 路径 | 说明 | 需要认证 |
|------|------|------|---------|
| POST | `/register` | 用户注册 | ❌ |
| POST | `/login` | 用户登录 | ❌ |
| POST | `/refresh` | 刷新令牌 | ❌ |
| GET | `/me` | 获取当前用户信息 | ✅ |
| PUT | `/me` | 更新当前用户信息 | ✅ |

### 配置器相关 (`/api/v1/configurator`)

| 方法 | 路径 | 说明 | 需要认证 | 权限要求 |
|------|------|------|---------|---------|
| POST | `/create` | 创建新配置 | ✅ | engineer+ |
| GET | `/{id}` | 获取配置详情 | ✅ | viewer+ |
| GET | `/` | 获取配置列表 | ✅ | viewer+ |
| PUT | `/{id}` | 更新配置 | ✅ | engineer+ (own) |
| DELETE | `/{id}` | 删除配置 | ✅ | engineer+ (own) |
| POST | `/{id}/approve` | 批准配置 | ✅ | admin |

### 产品相关 (`/api/v1/products`)

| 方法 | 路径 | 说明 | 需要认证 |
|------|------|------|---------|
| GET | `/` | 获取产品列表 | ❌ |
| GET | `/{id}` | 获取产品详情 | ❌ |
| GET | `/{id}/parameters` | 获取产品参数定义 | ❌ |

### 国际化相关 (`/api/v1/i18n`)

| 方法 | 路径 | 说明 | 需要认证 |
|------|------|------|---------|
| GET | `/translations/{language}` | 获取翻译文本 | ❌ |

## 用户角色和权限

### 角色定义

- **admin**: 管理员，拥有所有权限
- **engineer**: 工程师，可以创建、读取、更新、删除配置
- **viewer**: 查看者，只能读取配置
- **guest**: 访客，只能读取公开资源（产品信息）

### 权限矩阵

| 资源 | 操作 | admin | engineer | viewer | guest |
|------|------|-------|----------|--------|-------|
| configuration | create | ✅ | ✅ | ❌ | ❌ |
| configuration | read | ✅ | ✅ (own) | ✅ (own) | ❌ |
| configuration | update | ✅ | ✅ (own) | ❌ | ❌ |
| configuration | delete | ✅ | ✅ (own) | ❌ | ❌ |
| configuration | approve | ✅ | ❌ | ❌ | ❌ |
| product | read | ✅ | ✅ | ✅ | ✅ |
| user | manage | ✅ | ❌ | ❌ | ❌ |

## 数据模型

### User (用户)

```json
{
  "id": 1,
  "username": "user123",
  "email": "user@example.com",
  "full_name": "User Name",
  "role": "engineer",
  "is_active": true,
  "is_verified": false,
  "language": "ja",
  "created_at": "2024-01-01T00:00:00Z",
  "updated_at": "2024-01-01T00:00:00Z"
}
```

### Configuration (配置)

```json
{
  "id": 1,
  "configuration_id": "CONF-ABC123",
  "user_id": 1,
  "product_type": "vts1",
  "parameters": {
    "param1": "value1",
    "param2": 100
  },
  "result": {
    "message": "Configuration calculated successfully"
  },
  "status": "draft",
  "language": "ja",
  "name": "My Configuration",
  "description": "Configuration description",
  "created_at": "2024-01-01T00:00:00Z",
  "updated_at": "2024-01-01T00:00:00Z"
}
```

### Product (产品)

```json
{
  "id": 1,
  "product_code": "VTS1-001",
  "product_type": "vts1",
  "name_ja": "VTS Type 1",
  "name_en": "VTS Type 1",
  "description_ja": "製品説明",
  "description_en": "Product description",
  "specifications": {},
  "parameter_definitions": {},
  "is_active": true,
  "is_available": true
}
```

## 错误码

| 状态码 | 说明 |
|--------|------|
| 200 | 成功 |
| 201 | 创建成功 |
| 204 | 删除成功 |
| 400 | 请求错误 |
| 401 | 未认证 |
| 403 | 权限不足 |
| 404 | 资源不存在 |
| 500 | 服务器错误 |

## 示例请求

### 用户注册

```bash
curl -X POST "http://localhost:8000/api/v1/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "user123",
    "email": "user@example.com",
    "password": "Password123",
    "full_name": "User Name",
    "role": "engineer"
  }'
```

### 用户登录

```bash
curl -X POST "http://localhost:8000/api/v1/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=user123&password=Password123"
```

### 创建配置

```bash
curl -X POST "http://localhost:8000/api/v1/configurator/create" \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "product_type": "vts1",
    "parameters": {
      "param1": "value1",
      "param2": 100
    },
    "language": "ja",
    "name": "My Configuration"
  }'
```

## 数据库设置

### PostgreSQL连接

在 `.env` 文件中配置：

```env
DATABASE_URL=postgresql://user:password@localhost:5432/thk_configurator
```

### 数据库迁移

使用Alembic进行数据库迁移：

```bash
# 初始化迁移
alembic init alembic

# 创建迁移
alembic revision --autogenerate -m "Initial migration"

# 应用迁移
alembic upgrade head
```

## 环境变量

创建 `.env` 文件：

```env
# 应用设置
APP_NAME=THK VTS Configurator
APP_VERSION=2.0.0

# 数据库
DATABASE_URL=postgresql://user:password@localhost:5432/thk_configurator

# JWT
SECRET_KEY=your-secret-key-change-this-in-production
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
REFRESH_TOKEN_EXPIRE_DAYS=7

# CORS
CORS_ORIGINS=http://localhost:3000,http://localhost:5173
```

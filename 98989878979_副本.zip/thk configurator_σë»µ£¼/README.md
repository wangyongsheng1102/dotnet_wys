# THK VTS Configurator Ver2.0

THK VTS产品配置器 - 支持日英双语的Web应用程序

## 项目结构

```
thk-configurator/
├── frontend/          # React前端应用
│   ├── src/
│   │   ├── components/   # React组件
│   │   ├── pages/        # 页面组件
│   │   ├── hooks/        # 自定义Hooks
│   │   ├── services/     # API服务
│   │   ├── i18n/         # 国际化配置
│   │   ├── utils/        # 工具函数
│   │   └── types/        # TypeScript类型定义
│   ├── public/
│   └── package.json
├── backend/          # FastAPI后端应用
│   ├── app/
│   │   ├── api/         # API路由
│   │   ├── models/      # 数据模型
│   │   ├── services/    # 业务逻辑
│   │   ├── schemas/     # Pydantic模式
│   │   └── main.py      # 应用入口
│   ├── requirements.txt
│   └── README.md
├── docs/             # 项目文档
└── README.md
```

## 技术栈

### 前端
- React 18+
- TypeScript
- React Router
- react-i18next (国际化)
- Axios (HTTP客户端)
- Tailwind CSS / Material-UI (样式)

### 后端
- Python 3.10+
- FastAPI
- Pydantic (数据验证)
- SQLAlchemy (ORM，如需要数据库)
- python-i18n (国际化)

## 快速开始

### 1. 后端设置

```bash
# 进入后端目录
cd backend

# 创建虚拟环境
python -m venv venv

# 激活虚拟环境
# macOS/Linux:
source venv/bin/activate
# Windows:
# venv\Scripts\activate

# 安装依赖
pip install -r requirements.txt

# 启动后端服务
uvicorn app.main:app --reload
```

后端服务将在 http://localhost:8000 运行
API文档: http://localhost:8000/docs

### 2. 前端设置

```bash
# 进入前端目录
cd frontend

# 安装依赖
npm install

# 启动开发服务器
npm run dev
```

前端应用将在 http://localhost:3000 运行

### 3. 提取PDF文档内容（可选）

如果需要从PDF文档中提取需求信息：

```bash
# 安装PDF提取工具
pip install pdfplumber

# 运行提取脚本
python scripts/extract_pdf.py
```

## 功能特性

- ✅ 产品配置功能
- ✅ 日英双语支持
- ✅ 响应式设计
- ✅ RESTful API
- ✅ 数据验证

## 开发计划

详见 `需求整理.md`
